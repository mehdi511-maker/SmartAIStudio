import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:file_picker/file_picker.dart';

void main() => runApp(const SmartAIStudioApp());

class SmartAIStudioApp extends StatelessWidget {
  const SmartAIStudioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'کارگاه هوشمند',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF21A179),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF101512),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: ChatScreen(),
      ),
    );
  }
}

class ChatMessage {
  final String role;
  final String content;
  ChatMessage(this.role, this.content);

  Map<String, dynamic> toJson() => {'role': role, 'content': content};
  factory ChatMessage.fromJson(Map<String, dynamic> json) =>
      ChatMessage(json['role'] as String, json['content'] as String);
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  static const _storage = FlutterSecureStorage();
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final List<ChatMessage> _messages = [];
  String _endpoint = 'https://api.openai.com/v1/chat/completions';
  String _model = 'gpt-4o-mini';
  String _apiKey = '';
  bool _busy = false;
  String _attachmentText = '';

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _loadHistory();
  }

  Future<void> _loadSettings() async {
    final values = await Future.wait([
      _storage.read(key: 'api_key'),
      _storage.read(key: 'endpoint'),
      _storage.read(key: 'model'),
    ]);
    if (!mounted) return;
    setState(() {
      _apiKey = values[0] ?? '';
      _endpoint = values[1] ?? _endpoint;
      _model = values[2] ?? _model;
    });
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('chat_history');
    if (raw == null) return;
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      if (!mounted) return;
      setState(() {
        _messages.addAll(decoded.map((e) =>
            ChatMessage.fromJson(Map<String, dynamic>.from(e as Map))));
      });
    } catch (_) {
      // Ignore an invalid or old history record.
    }
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'chat_history',
      jsonEncode(_messages.map((m) => m.toJson()).toList()),
    );
  }

  Future<void> _settings() async {
    final endpoint = TextEditingController(text: _endpoint);
    final model = TextEditingController(text: _model);
    final key = TextEditingController(text: _apiKey);
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('تنظیمات اتصال هوش مصنوعی'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: endpoint, decoration: const InputDecoration(labelText: 'آدرس API')),
                TextField(controller: model, decoration: const InputDecoration(labelText: 'نام مدل')),
                TextField(
                  controller: key,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'کلید API'),
                ),
                const SizedBox(height: 8),
                const Text(
                  'این برنامه از APIهای سازگار با قالب OpenAI استفاده می‌کند. سازگاری هر سرویس باید جداگانه بررسی شود.',
                  style: TextStyle(fontSize: 12, color: Colors.white70),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('انصراف'),
            ),
            FilledButton(
              onPressed: () async {
                final newEndpoint = endpoint.text.trim();
                if (!newEndpoint.startsWith('https://') &&
                    !newEndpoint.startsWith('http://')) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('آدرس API معتبر نیست.')),
                  );
                  return;
                }
                await _storage.write(key: 'endpoint', value: newEndpoint);
                await _storage.write(key: 'model', value: model.text.trim());
                await _storage.write(key: 'api_key', value: key.text.trim());
                if (!mounted) return;
                setState(() {
                  _endpoint = newEndpoint;
                  _model = model.text.trim();
                  _apiKey = key.text.trim();
                });
                if (dialogContext.mounted) Navigator.pop(dialogContext);
              },
              child: const Text('ذخیره'),
            ),
          ],
        ),
      ),
    );
    endpoint.dispose();
    model.dispose();
    key.dispose();
  }

  Future<void> _pickFiles() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      withData: true,
      type: FileType.custom,
      allowedExtensions: ['txt', 'md', 'json', 'dart', 'html', 'css', 'js', 'py', 'yaml', 'yml', 'xml', 'java', 'kt'],
    );
    if (result == null) return;
    final parts = <String>[];
    for (final file in result.files) {
      final bytes = file.bytes;
      if (bytes == null) continue;
      if (bytes.length > 200000) {
        parts.add('\n[فایل ${file.name} به دلیل بزرگ بودن (بیش از ۲۰۰ کیلوبایت) اضافه نشد.]');
        continue;
      }
      parts.add('\n--- فایل: ${file.name} ---\n${utf8.decode(bytes, allowMalformed: true)}');
    }
    setState(() => _attachmentText = parts.join('\n'));
    if (mounted && parts.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${parts.length} فایل متنی آماده ارسال شد.')),
      );
    }
  }

  Future<void> _send() async {
    final prompt = _input.text.trim();
    if (prompt.isEmpty && _attachmentText.isEmpty) return;
    if (_apiKey.isEmpty) {
      await _settings();
      if (_apiKey.isEmpty) return;
    }
    final fullPrompt = [
      if (prompt.isNotEmpty) prompt,
      if (_attachmentText.isNotEmpty) '\nمحتوای فایل‌های پیوست:\n$_attachmentText',
    ].join('\n');
    setState(() {
      _messages.add(ChatMessage('user', fullPrompt));
      _busy = true;
      _input.clear();
      _attachmentText = '';
    });
    await _saveHistory();
    _jumpToBottom();

    try {
      final response = await http.post(
        Uri.parse(_endpoint),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $_apiKey',
        },
        body: jsonEncode({
          'model': _model,
          'messages': _messages.map((m) => m.toJson()).toList(),
          'temperature': 0.4,
        }),
      ).timeout(const Duration(seconds: 90));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('HTTP ${response.statusCode}: ${_short(response.body)}');
      }
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      final content = data['choices']?[0]?['message']?['content'];
      String answer;
      if (content is String) {
        answer = content;
      } else if (content is List) {
        answer = content.map((part) {
          if (part is Map && part['text'] is String) return part['text'];
          return '';
        }).join('\n');
      } else {
        answer = 'پاسخ دریافتی قابل خواندن نیست.';
      }
      if (!mounted) return;
      setState(() => _messages.add(ChatMessage('assistant', answer)));
      await _saveHistory();
    } catch (e) {
      if (!mounted) return;
      setState(() => _messages.add(
        ChatMessage('assistant', 'خطا در ارتباط با سرویس:\n$e'),
      ));
      await _saveHistory();
    } finally {
      if (mounted) {
        setState(() => _busy = false);
        _jumpToBottom();
      }
    }
  }

  String _short(String value) =>
      value.length > 700 ? '${value.substring(0, 700)}…' : value;

  void _jumpToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _clearChat() async {
    setState(_messages.clear);
    await _saveHistory();
  }

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('کارگاه هوشمند'),
            Text('دستیار تولید نرم‌افزار و کدنویسی',
                style: TextStyle(fontSize: 11, color: Colors.white60)),
          ],
        ),
        actions: [
          IconButton(tooltip: 'تنظیمات API', onPressed: _settings, icon: const Icon(Icons.settings)),
          IconButton(tooltip: 'گفت‌وگوی جدید', onPressed: _clearChat, icon: const Icon(Icons.delete_outline)),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _messages.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.auto_awesome, size: 56, color: Color(0xFF21A179)),
                          SizedBox(height: 14),
                          Text('به کارگاه هوشمند خوش آمدید',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          SizedBox(height: 8),
                          Text('برای شروع، کلید API را در تنظیمات وارد کنید و درخواست خود را بنویسید.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.white70)),
                        ],
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.all(12),
                    itemCount: _messages.length,
                    itemBuilder: (context, index) {
                      final message = _messages[index];
                      final isUser = message.role == 'user';
                      return Align(
                        alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          constraints: const BoxConstraints(maxWidth: 680),
                          margin: const EdgeInsets.symmetric(vertical: 6),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: isUser ? const Color(0xFF174C3C) : const Color(0xFF202923),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: isUser
                              ? SelectableText(message.content)
                              : MarkdownBody(
                                  data: message.content,
                                  selectable: true,
                                  styleSheet: MarkdownStyleSheet.fromTheme(Theme.of(context)),
                                ),
                        ),
                      );
                    },
                  ),
          ),
          if (_busy) const LinearProgressIndicator(minHeight: 2),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(
                children: [
                  if (_attachmentText.isNotEmpty)
                    Align(
                      alignment: Alignment.centerRight,
                      child: Text('فایل متنی برای ارسال آماده است',
                          style: TextStyle(color: Colors.green.shade300, fontSize: 12)),
                    ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      IconButton(
                        tooltip: 'افزودن فایل متنی',
                        onPressed: _busy ? null : _pickFiles,
                        icon: const Icon(Icons.attach_file),
                      ),
                      Expanded(
                        child: TextField(
                          controller: _input,
                          minLines: 1,
                          maxLines: 5,
                          textInputAction: TextInputAction.newline,
                          decoration: InputDecoration(
                            hintText: 'درخواست خود را بنویسید…',
                            filled: true,
                            fillColor: const Color(0xFF202923),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: BorderSide.none,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      IconButton.filled(
                        tooltip: 'ارسال',
                        onPressed: _busy ? null : _send,
                        icon: const Icon(Icons.send),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
